package com.example.julestest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JulesTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
